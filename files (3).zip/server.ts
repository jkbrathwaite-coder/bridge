/**
 * BridgePath Group — Supabase Server Client
 * ─────────────────────────────────────────────
 * Use this in Next.js:
 *   - Server Components (app/page.tsx, app/layout.tsx)
 *   - Route Handlers (app/api/*)
 *   - Server Actions
 *
 * NOT used in the Vite SPA — use client.ts there instead.
 *
 * Usage:
 *   import { createClient } from '@/utils/supabase/server'
 *   const supabase = await createClient()
 */

import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!;

export const createClient = async () => {
  const cookieStore = await cookies();

  return createServerClient(supabaseUrl, supabaseKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) =>
            cookieStore.set(name, value, options)
          );
        } catch {
          // Called from a Server Component — safe to ignore.
          // Middleware handles session refresh.
        }
      },
    },
  });
};
