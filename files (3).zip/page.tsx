/**
 * BridgePath Group — Example Next.js Server Component
 * ─────────────────────────────────────────────────────
 * File: app/page.tsx  (or app/dashboard/page.tsx)
 *
 * This is the Next.js equivalent of what the Supabase dashboard
 * showed in their setup guide — adapted from 'todos' to BridgePath clients.
 *
 * The server component fetches data at request time — no useEffect needed.
 * For the Vite SPA, use the functions in supabase/supabase.js instead.
 */

import { createClient } from '@/utils/supabase/server'

export default async function Page() {
  const supabase = await createClient()

  // Fetch active clients with their current milestone
  const { data: clients, error } = await supabase
    .from('clients')
    .select(`
      id,
      full_name,
      email,
      service_type,
      current_milestone,
      milestone_step,
      case_status
    `)
    .eq('case_status', 'active')
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Supabase error:', error.message)
    return <div>Failed to load clients: {error.message}</div>
  }

  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#1B3A7A', marginBottom: '1rem' }}>
        BridgePath Group — Active Clients
      </h1>
      <p style={{ color: '#6B7794', marginBottom: '1.5rem' }}>
        {clients?.length ?? 0} active clients
      </p>
      <ul style={{ listStyle: 'none', padding: 0, display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {clients?.map((client) => (
          <li key={client.id} style={{
            padding: '1rem 1.25rem',
            border: '1px solid rgba(27,58,122,0.11)',
            borderRadius: '10px',
            background: '#fff',
          }}>
            <div style={{ fontWeight: 700, color: '#111827' }}>{client.full_name}</div>
            <div style={{ fontSize: '13px', color: '#6B7794', marginTop: '3px' }}>
              {client.service_type?.replace(/_/g, ' ')} ·{' '}
              Step {client.milestone_step} of 14 ·{' '}
              {client.current_milestone?.replace(/_/g, ' ')}
            </div>
            <div style={{ fontSize: '12px', color: '#6B7794', marginTop: '2px' }}>
              {client.email}
            </div>
          </li>
        ))}
      </ul>
    </main>
  )
}
