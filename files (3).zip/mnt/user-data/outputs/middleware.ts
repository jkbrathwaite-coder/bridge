/**
 * BridgePath Group — Next.js Middleware
 * ──────────────────────────────────────
 * Place this file at the PROJECT ROOT (same level as package.json).
 * It runs on every request and keeps Supabase auth sessions alive.
 *
 * File: middleware.ts  (NOT inside /app or /pages)
 */

import { type NextRequest } from "next/server";
import { createClient } from "@/utils/supabase/middleware";

export async function middleware(request: NextRequest) {
  return createClient(request);
}

export const config = {
  matcher: [
    /*
     * Match all request paths EXCEPT:
     * - _next/static  (static files)
     * - _next/image   (image optimisation)
     * - favicon.ico
     * - Public assets (.svg, .png, .jpg, .jpeg, .gif, .webp)
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
