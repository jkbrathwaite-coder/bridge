/**
 * BridgePath Group — Supabase Browser Client
 * ─────────────────────────────────────────────
 * Use this in:
 *   - Vite SPA (bridgepath-platform.jsx) → import.meta.env.VITE_*
 *   - Next.js client components ('use client') → process.env.NEXT_PUBLIC_*
 *
 * Usage:
 *   import { createClient } from '@/utils/supabase/client'
 *   const supabase = createClient()
 */

import { createBrowserClient } from "@supabase/ssr";

// Works in both Vite (import.meta.env) and Next.js (process.env)
const supabaseUrl =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_SUPABASE_URL) ||
  process.env.NEXT_PUBLIC_SUPABASE_URL!;

const supabaseKey =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!;

export const createClient = () =>
  createBrowserClient(supabaseUrl, supabaseKey);

// Singleton for use outside React (e.g. in supabase.js service functions)
export const supabase = createClient();
