/**
 * BridgePath Group — Supabase Middleware Client
 * ─────────────────────────────────────────────
 * Refreshes the user session on every request so Server Components
 * always have an up-to-date session.
 *
 * Wire this into Next.js middleware.ts (project root):
 *
 *   import { createClient } from '@/utils/supabase/middleware'
 *   export async function middleware(request: NextRequest) {
 *     return createClient(request)
 *   }
 *   export const config = {
 *     matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
 *   }
 */

import { createServerClient } from "@supabase/ssr";
import { type NextRequest, NextResponse } from "next/server";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!;

export const createClient = (request: NextRequest) => {
  // Start with an unmodified response
  let supabaseResponse = NextResponse.next({
    request: { headers: request.headers },
  });

  createServerClient(supabaseUrl, supabaseKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        // Set on request (for downstream middleware)
        cookiesToSet.forEach(({ name, value }) =>
          request.cookies.set(name, value)
        );
        // Rebuild response so cookies propagate to the browser
        supabaseResponse = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) =>
          supabaseResponse.cookies.set(name, value, options)
        );
      },
    },
  });

  return supabaseResponse;
};
