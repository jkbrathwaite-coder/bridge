/**
 * BridgePath Group — Supabase Client Library
 * ───────────────────────────────────────────
 * Typed query functions that replace the static seed data
 * (INITIAL_CLIENTS, APPOINTMENTS, VAULT_DOCS, CALL_LOG)
 * in bridgepath-platform.jsx with live Supabase reads/writes.
 *
 * SETUP:
 *   npm install @supabase/supabase-js
 *
 *   Add to .env:
 *     VITE_SUPABASE_URL=https://xxxx.supabase.co
 *     VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6...
 *
 * USAGE in bridgepath-platform.jsx:
 *   import { getClients, getAppointments, ... } from './lib/supabase'
 *   Replace useState(INITIAL_CLIENTS) with useEffect → getClients()
 */

import { createBrowserClient } from '@supabase/ssr'

// ── CLIENT INIT ───────────────────────────────────────────────
// Uses @supabase/ssr for correct cookie-based session handling.
// Env vars: VITE_SUPABASE_URL + VITE_SUPABASE_PUBLISHABLE_KEY (Vite)
//        or NEXT_PUBLIC_SUPABASE_URL + NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY (Next.js)
const SUPABASE_URL =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  'https://wxpfudbbsloqnmwypzgo.supabase.co'

const SUPABASE_KEY =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
  'sb_publishable_K_nRY7QkJCCaEzt_dAyiFQ_yxxJGf6J'

export const supabase = createBrowserClient(SUPABASE_URL, SUPABASE_KEY)

// ── AUTH ──────────────────────────────────────────────────────
export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw error
  return data
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

export function onAuthChange(callback) {
  return supabase.auth.onAuthStateChange(callback)
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser()
  return user
}

// ── CLIENTS ───────────────────────────────────────────────────

/**
 * Fetch all active clients with their current milestone.
 * Replaces INITIAL_CLIENTS in bridgepath-platform.jsx.
 * Maps DB rows → the shape the UI components expect.
 */
export async function getClients({ status = 'active' } = {}) {
  const { data, error } = await supabase
    .from('clients')
    .select(`
      id,
      full_name,
      email,
      phone,
      preferred_language,
      country_of_origin,
      service_type,
      case_status,
      current_milestone,
      milestone_step,
      is_virtual,
      assigned_to,
      created_at,
      updated_at
    `)
    .eq('case_status', status)
    .order('created_at', { ascending: false })

  if (error) throw error

  // Map to UI shape — mirrors INITIAL_CLIENTS structure
  return (data || []).map(mapClientToUI)
}

/**
 * Search clients by name, email, or phone.
 * Powers the search bar in ClientsView.
 */
export async function searchClients(query) {
  if (!query || query.trim().length < 2) return getClients()

  const { data, error } = await supabase
    .rpc('search_clients', { query: query.trim() })

  if (error) throw error
  return (data || []).map(mapClientToUI)
}

/**
 * Fetch a single client with full detail — journey events, documents, appointments, notes.
 * Used in ClientDetail view.
 */
export async function getClientDetail(clientId) {
  const [clientRes, journeyRes, docsRes, apptsRes, notesRes] = await Promise.all([
    supabase
      .from('clients')
      .select('*')
      .eq('id', clientId)
      .single(),

    supabase
      .from('journey_events')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: true }),

    supabase
      .from('documents')
      .select('*')
      .eq('client_id', clientId)
      .order('category', { ascending: true }),

    supabase
      .from('appointments')
      .select('*')
      .eq('client_id', clientId)
      .order('scheduled_at', { ascending: false })
      .limit(10),

    supabase
      .from('notes')
      .select('*')
      .eq('client_id', clientId)
      .order('is_pinned', { ascending: false })
      .order('created_at', { ascending: false }),
  ])

  if (clientRes.error) throw clientRes.error

  return {
    client:       mapClientToUI(clientRes.data),
    journeyEvents: journeyRes.data || [],
    documents:    docsRes.data || [],
    appointments: (apptsRes.data || []).map(mapApptToUI),
    notes:        notesRes.data || [],
  }
}

/**
 * Create a new client from AI receptionist intake.
 */
export async function createClient(intake) {
  const { data, error } = await supabase
    .from('clients')
    .insert({
      full_name:          intake.name,
      email:              intake.email,
      phone:              intake.phone,
      preferred_language: intake.language === 'Spanish' ? 'es' : 'en',
      country_of_origin:  intake.country || null,
      service_type:       mapServiceType(intake.service),
      is_virtual:         intake.format === 'Virtual',
      intake_notes:       intake.notes || null,
      case_status:        'active',
      current_milestone:  'initial_contact',
      milestone_step:     1,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * Advance a client's journey milestone.
 * Triggers the DB trigger that auto-logs a journey_event.
 */
export async function advanceMilestone(clientId, milestone, stepNumber) {
  const { data, error } = await supabase
    .from('clients')
    .update({
      current_milestone: milestone,
      milestone_step:    stepNumber,
    })
    .eq('id', clientId)
    .select()
    .single()

  if (error) throw error
  return data
}

// ── APPOINTMENTS ──────────────────────────────────────────────

/**
 * Fetch upcoming appointments for the dashboard.
 * Replaces APPOINTMENTS in bridgepath-platform.jsx.
 */
export async function getAppointments({ dateFrom, dateTo, status = 'scheduled' } = {}) {
  let query = supabase
    .from('appointments')
    .select(`
      id,
      client_id,
      appointment_type,
      format,
      status,
      scheduled_at,
      duration_minutes,
      meeting_url,
      calcom_booking_uid,
      clients ( full_name, preferred_language )
    `)
    .eq('status', status)
    .order('scheduled_at', { ascending: true })

  if (dateFrom) query = query.gte('scheduled_at', dateFrom)
  if (dateTo)   query = query.lte('scheduled_at', dateTo)

  const { data, error } = await query
  if (error) throw error
  return (data || []).map(mapApptToUI)
}

/**
 * Fetch today's appointments specifically.
 */
export async function getTodayAppointments() {
  const today = new Date()
  const start = new Date(today.setHours(0,0,0,0)).toISOString()
  const end   = new Date(today.setHours(23,59,59,999)).toISOString()
  return getAppointments({ dateFrom: start, dateTo: end })
}

/**
 * Create an appointment — called after Cal.com booking confirmed.
 */
export async function createAppointment({
  clientId,
  appointmentType,
  format,
  scheduledAt,
  durationMinutes,
  meetingUrl,
  calcomBookingUid,
}) {
  const { data, error } = await supabase
    .from('appointments')
    .insert({
      client_id:          clientId,
      appointment_type:   appointmentType,
      format:             format === 'Virtual' ? 'virtual' : 'in_person',
      status:             'scheduled',
      scheduled_at:       scheduledAt,
      duration_minutes:   durationMinutes,
      meeting_url:        meetingUrl || null,
      calcom_booking_uid: calcomBookingUid || null,
    })
    .select()
    .single()

  if (error) throw error

  // Advance milestone to consultation_scheduled if still at initial_contact
  await supabase.rpc('advance_milestone_on_booking', {
    p_client_id:  clientId,
    p_calcom_uid: calcomBookingUid || '',
  })

  return data
}

/**
 * Cancel an appointment (soft — updates status, does not delete).
 */
export async function cancelAppointment(appointmentId, reason = '') {
  const { data, error } = await supabase
    .from('appointments')
    .update({
      status:              'cancelled',
      cancellation_reason: reason,
      cancelled_at:        new Date().toISOString(),
    })
    .eq('id', appointmentId)
    .select()
    .single()

  if (error) throw error
  return data
}

// ── DOCUMENTS (BridgeVault™) ──────────────────────────────────

/**
 * Get all documents for a client.
 * Replaces VAULT_DOCS in bridgepath-platform.jsx.
 */
export async function getDocuments(clientId) {
  const { data, error } = await supabase
    .from('documents')
    .select('*')
    .eq('client_id', clientId)
    .order('category', { ascending: true })

  if (error) throw error
  return (data || []).map(mapDocToUI)
}

/**
 * Update document status (e.g. 'missing' → 'received' → 'verified').
 */
export async function updateDocumentStatus(documentId, status, reviewedBy = null) {
  const update = {
    status,
    ...(status === 'verified' || status === 'in_review' ? {
      reviewed_by: reviewedBy,
      reviewed_at: new Date().toISOString(),
    } : {}),
    ...(status === 'received' ? { uploaded_at: new Date().toISOString() } : {}),
  }

  const { data, error } = await supabase
    .from('documents')
    .update(update)
    .eq('id', documentId)
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * Upload a document file to BridgeVault™ (Supabase Storage).
 * Returns the storage path to save in the documents table.
 */
export async function uploadDocumentFile(clientId, documentId, file) {
  const ext  = file.name.split('.').pop()
  const path = `clients/${clientId}/${documentId}.${ext}`

  const { error: uploadError } = await supabase.storage
    .from('bridgevault')
    .upload(path, file, { upsert: true, contentType: file.type })

  if (uploadError) throw uploadError

  // Update the document record with the storage path
  const { data, error } = await supabase
    .from('documents')
    .update({
      storage_path: path,
      file_name:    file.name,
      file_size:    file.size,
      mime_type:    file.type,
      status:       'received',
      uploaded_at:  new Date().toISOString(),
    })
    .eq('id', documentId)
    .select()
    .single()

  if (error) throw error
  return data
}

/**
 * Get a signed URL to view/download a document (valid 60 minutes).
 */
export async function getDocumentUrl(storagePath) {
  const { data, error } = await supabase.storage
    .from('bridgevault')
    .createSignedUrl(storagePath, 3600)

  if (error) throw error
  return data.signedUrl
}

// ── CALL LOGS ─────────────────────────────────────────────────

/**
 * Fetch today's call log for the receptionist view.
 * Replaces CALL_LOG in bridgepath-platform.jsx.
 */
export async function getCallLog({ date } = {}) {
  const d = date || new Date()
  const start = new Date(d).setHours(0,0,0,0)
  const end   = new Date(d).setHours(23,59,59,999)

  const { data, error } = await supabase
    .from('call_logs')
    .select(`
      id,
      caller_name,
      caller_phone,
      caller_language,
      outcome,
      duration_seconds,
      summary,
      legal_question_flagged,
      called_at,
      clients ( full_name )
    `)
    .gte('called_at', new Date(start).toISOString())
    .lte('called_at', new Date(end).toISOString())
    .order('called_at', { ascending: false })

  if (error) throw error
  return (data || []).map(mapCallToUI)
}

/**
 * Log a completed AI receptionist call.
 * Called when Javid clicks "End call & log" in the chat.
 */
export async function logCall({
  clientId,
  callerName,
  callerPhone,
  callerEmail,
  callerLanguage,
  outcome,
  durationSeconds,
  summary,
  serviceRequested,
  legalQuestionFlagged,
  transcript,
  appointmentId,
}) {
  const { data, error } = await supabase
    .from('call_logs')
    .insert({
      client_id:              clientId || null,
      caller_name:            callerName,
      caller_phone:           callerPhone || null,
      caller_email:           callerEmail || null,
      caller_language:        callerLanguage || 'en',
      outcome:                outcome,
      duration_seconds:       durationSeconds || null,
      summary:                summary,
      service_requested:      serviceRequested || null,
      legal_question_flagged: legalQuestionFlagged || false,
      transcript:             transcript ? JSON.stringify(transcript) : null,
      appointment_booked_id:  appointmentId || null,
    })
    .select()
    .single()

  if (error) throw error
  return data
}

// ── DASHBOARD ─────────────────────────────────────────────────

/**
 * Get dashboard stats — powers the 4 StatCards on the dashboard.
 */
export async function getDashboardStats() {
  const { data, error } = await supabase.rpc('get_dashboard_stats')
  if (error) throw error
  return data
}

// ── REALTIME SUBSCRIPTIONS ────────────────────────────────────

/**
 * Subscribe to new call logs in real time.
 * Shows incoming calls live on the receptionist dashboard.
 */
export function subscribeToCallLog(onNewCall) {
  return supabase
    .channel('call_logs')
    .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'call_logs' },
      payload => onNewCall(mapCallToUI(payload.new))
    )
    .subscribe()
}

/**
 * Subscribe to client milestone changes.
 * Keeps Journey Tracker in sync across tabs.
 */
export function subscribeToMilestones(onMilestoneChange) {
  return supabase
    .channel('client_milestones')
    .on('postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'clients',
        filter: 'case_status=eq.active' },
      payload => onMilestoneChange(mapClientToUI(payload.new))
    )
    .subscribe()
}

// ── CALCOM WEBHOOK HANDLER (Supabase Edge Function) ───────────
/**
 * Use this in a Supabase Edge Function: supabase/functions/calcom-webhook/index.ts
 * It handles Cal.com BOOKING_CREATED → creates appointment + advances milestone.
 *
 * Deploy: supabase functions deploy calcom-webhook
 */
export const CALCOM_WEBHOOK_HANDLER = `
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

// Supabase Edge Functions have access to these automatically
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')! // service role bypasses RLS — server only
)

Deno.serve(async (req) => {
  const payload = await req.json()
  const { triggerEvent, payload: booking } = payload

  if (triggerEvent === 'BOOKING_CREATED') {
    const attendee = booking.attendees?.[0]
    const meta     = booking.metadata || {}

    // 1. Find or create client by email
    let { data: client } = await supabase
      .from('clients')
      .select('id')
      .eq('email', attendee?.email)
      .single()

    if (!client) {
      const { data: newClient } = await supabase
        .from('clients')
        .insert({
          full_name:         attendee?.name,
          email:             attendee?.email,
          phone:             meta.phone || null,
          preferred_language: attendee?.language || 'en',
          service_type:      'other',
          case_status:       'active',
          current_milestone: 'initial_contact',
          milestone_step:    1,
        })
        .select('id')
        .single()
      client = newClient
    }

    // 2. Create appointment
    const apptTypeMap = {
      'initial-consultation':     'initial_consultation',
      'follow-up-consultation':   'follow_up_consultation',
      'document-review':          'document_review',
      'translation-consultation': 'translation_consultation',
    }
    const durationMap = {
      'initial_consultation':    60,
      'follow_up_consultation':  30,
      'document_review':         45,
      'translation_consultation':30,
    }
    const apptType = apptTypeMap[booking.eventTypeSlug] || 'initial_consultation'

    await supabase.from('appointments').insert({
      client_id:          client.id,
      appointment_type:   apptType,
      format:             'virtual',
      status:             'scheduled',
      scheduled_at:       booking.startTime,
      duration_minutes:   durationMap[apptType],
      meeting_url:        booking.meetingUrl,
      calcom_booking_uid: booking.uid,
    })

    // 3. Advance milestone
    await supabase.rpc('advance_milestone_on_booking', {
      p_client_id:  client.id,
      p_calcom_uid: booking.uid,
    })
  }

  if (triggerEvent === 'BOOKING_CANCELLED') {
    await supabase
      .from('appointments')
      .update({ status: 'cancelled', cancelled_at: new Date().toISOString() })
      .eq('calcom_booking_uid', booking.uid)
  }

  if (triggerEvent === 'BOOKING_RESCHEDULED') {
    await supabase
      .from('appointments')
      .update({ scheduled_at: booking.startTime, status: 'scheduled' })
      .eq('calcom_booking_uid', booking.uid)
  }

  return new Response(JSON.stringify({ received: true }), {
    headers: { 'Content-Type': 'application/json' }
  })
})
`

// ── MAPPERS ───────────────────────────────────────────────────
// Convert DB row shapes → the UI component shapes used in bridgepath-platform.jsx

const SERVICE_LABELS = {
  work_permit_ead:          'Work Permit · EAD',
  work_permit_h1b:          'Work Permit · H-1B Transfer',
  green_card_family:        'Green Card · Family-based',
  green_card_employment:    'Green Card · Employment-based',
  citizenship_naturalization:'Citizenship · Naturalization',
  family_petition:          'Family Petition',
  document_review:          'Document Review',
  translation:              'Translation',
  other:                    'Other',
}

const MILESTONE_LABELS = {
  initial_contact:           'Initial contact',
  consultation_scheduled:    'Consultation scheduled',
  consultation_completed:    'Consultation completed',
  client_intake_completed:   'Client intake completed',
  document_checklist_sent:   'Document checklist sent',
  documents_received:        'Documents received',
  documents_reviewed:        'Documents reviewed',
  application_prepared:      'Application prepared',
  client_review:             'Client review',
  application_submitted:     'Application submitted',
  waiting_government_updates:'Waiting for government updates',
  biometrics_appointment:    'Biometrics appointment',
  interview_scheduled:       'Interview scheduled',
  case_completed:            'Case completed',
}

const MILESTONE_TO_STEP = Object.fromEntries(
  Object.keys(MILESTONE_LABELS).map((k, i) => [k, i + 1])
)

// Color palette — mirrors INITIAL_CLIENTS in bridgepath-platform.jsx
const SERVICE_COLORS = {
  work_permit_ead:          { color:'#1A8870', bgColor:'#D0F4EC' },
  work_permit_h1b:          { color:'#7C3AED', bgColor:'#EDE9FE' },
  green_card_family:        { color:'#C98E00', bgColor:'#FFF8E1' },
  green_card_employment:    { color:'#DC2626', bgColor:'#FEF2F2' },
  citizenship_naturalization:{ color:'#1B3A7A', bgColor:'rgba(27,58,122,0.08)' },
  family_petition:          { color:'#0369A1', bgColor:'#E0F2FE' },
  document_review:          { color:'#6B7794', bgColor:'#F3F4F6' },
  translation:              { color:'#6B7794', bgColor:'#F3F4F6' },
  other:                    { color:'#6B7794', bgColor:'#F3F4F6' },
}

function mapClientToUI(row) {
  if (!row) return null
  const name    = row.full_name || ''
  const words   = name.trim().split(' ')
  const initials = (words[0]?.[0] || '') + (words[1]?.[0] || '')
  const colors  = SERVICE_COLORS[row.service_type] || SERVICE_COLORS.other
  const step    = row.milestone_step || MILESTONE_TO_STEP[row.current_milestone] || 1

  return {
    id:       row.id,
    initials: initials.toUpperCase(),
    name:     row.full_name,
    email:    row.email,
    phone:    row.phone,
    type:     SERVICE_LABELS[row.service_type] || row.service_type,
    step,
    steps:    14,
    color:    colors.color,
    bgColor:  colors.bgColor,
    lang:     row.preferred_language,
    country:  row.country_of_origin,
    status:   MILESTONE_LABELS[row.current_milestone] || row.current_milestone,
    caseStatus: row.case_status,
    isVirtual:  row.is_virtual,
    createdAt:  row.created_at,
  }
}

function mapApptToUI(row) {
  if (!row) return null
  const d = new Date(row.scheduled_at)
  return {
    id:       row.id,
    clientId: row.client_id,
    day:      String(d.getDate()),
    mon:      d.toLocaleString('en-US', { month: 'short' }),
    name:     row.clients?.full_name || 'Client',
    type:     row.appointment_type?.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) || '',
    format:   row.format === 'virtual' ? 'Virtual' : 'In-person',
    duration: `${row.duration_minutes} min`,
    time:     d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
    status:   row.status,
    meetingUrl: row.meeting_url,
    calcomUid:  row.calcom_booking_uid,
  }
}

function mapDocToUI(row) {
  if (!row) return null
  const ICONS = {
    identity: '🪪', immigration: '📄', employment: '💼',
    application: '📝', correspondence: '✉️', other: '📁',
  }
  const STATUS_MAP = { missing: 'miss', received: 'ok', in_review: 'rev', verified: 'ok', rejected: 'miss' }
  return {
    id:       row.id,
    icon:     ICONS[row.category] || '📄',
    label:    row.label,
    meta:     row.notes || (row.uploaded_at ? `Uploaded ${new Date(row.uploaded_at).toLocaleDateString('en-US',{month:'short',day:'numeric'})}` : 'Not yet uploaded'),
    status:   STATUS_MAP[row.status] || 'miss',
    cat:      row.category === 'application' ? 'application' : 'identity',
    expiresAt: row.expires_at,
    storagePath: row.storage_path,
  }
}

function mapCallToUI(row) {
  if (!row) return null
  const name = row.clients?.full_name || row.caller_name || 'New caller'
  const words = name.trim().split(' ')
  const initials = ((words[0]?.[0] || '') + (words[1]?.[0] || '')).toUpperCase() || '?'
  const OUTCOME_TAGS = {
    appointment_booked:    { tag:'Booked',    tagType:'success' },
    appointment_confirmed: { tag:'Confirmed', tagType:'success' },
    information_provided:  { tag:'Info only', tagType:'info'    },
    legal_escalated:       { tag:'Escalated', tagType:'legal'   },
    voicemail:             { tag:'Voicemail', tagType:'info'    },
    no_answer:             { tag:'No answer', tagType:'info'    },
    callback_requested:    { tag:'Callback',  tagType:'pending' },
  }
  const tagInfo = OUTCOME_TAGS[row.outcome] || { tag: row.outcome, tagType:'info' }
  return {
    id:       row.id,
    initials,
    name,
    detail:   row.summary,
    time:     new Date(row.called_at).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}),
    dur:      row.duration_seconds ? `${Math.ceil(row.duration_seconds / 60)} min` : null,
    ...tagInfo,
    legalFlagged: row.legal_question_flagged,
  }
}

function mapServiceType(serviceLabel) {
  const map = {
    'Work permit (EAD)':           'work_permit_ead',
    'Green card':                  'green_card_family',
    'Citizenship':                 'citizenship_naturalization',
    'Family petition':             'family_petition',
    'Document review':             'document_review',
    'Translation consultation':    'translation',
  }
  return map[serviceLabel] || 'other'
}
